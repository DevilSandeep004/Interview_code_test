import 'dart:io';

import 'package:flutter/cupertino.dart';

class FeedModal {
  String? image;
  String? name;
  String? comment;
  String? postTime;
  String? postImage;
  Widget? goto;
  bool? isLike = false;
  String? noOfLike;
  String? noOfComments;
  File? newPost;

  FeedModal(this.name, this.image, this.goto, this.isLike, this.noOfComments,
      this.noOfLike, this.postImage, this.postTime, this.comment, this.newPost);
}
