import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

//image path
const imagePath = "assets/images/";

//Linear gradient
const linearGrad = LinearGradient(
  begin: Alignment.centerLeft,
  end: Alignment.centerRight,
  colors: [
    Color(0xFFef0178),
    Color(0xFF7b05c3),
  ],
);

enum ValidationEnum { normal, password, mobile }

// mobile Reg
RegExp mobileNumberRegExp = RegExp(r'(^(?:[+0]9)?[0-9]{10,13}$)');

String? commonFormValidation(
    {ValidationEnum type = ValidationEnum.normal,
    required String? value,
    String message = "*Required",
    String password = "",
    bool isExist = false}) {
  if (value == null || value.isEmpty) {
    return message;
  } else if (type == ValidationEnum.mobile) {
    if (!mobileNumberRegExp.hasMatch(value)) {
      return 'Please enter a valid mobile Number';
    }
  } else if (type == ValidationEnum.password) {
    if (value.length < 6) {
      return 'Password should be greater than 6 character';
    }
  }
  return null;
}

//TextFormField
class CommonTextFormFieldClass extends StatefulWidget {
  final Color hintTextColor;
  final String? labelText;
  final Function()? onTap;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final Widget? suffixWidget;
  final String hintText;
  final String errorText;
  final int? maxLength;
  final int? maxLines;
  final TextInputType? keyboardType;
  final bool isRead;
  final bool obscure;
  final bool isEnableBorder;
  final Function(String)? onChange;
  final String? Function(String?)? validation;
  final TextEditingController? controller;
  final List<TextInputFormatter>? inputFormatters;

  const CommonTextFormFieldClass({
    super.key,
    required this.hintText,
    this.controller,
    this.suffixIcon,
    this.suffixWidget,
    this.maxLines = 1,
    this.maxLength,
    this.keyboardType,
    this.prefixIcon,
    this.onTap,
    this.onChange,
    this.validation,
    this.hintTextColor = Colors.white,
    this.errorText = '',
    this.isRead = false,
    this.obscure = false,
    this.inputFormatters,
    this.labelText,
    this.isEnableBorder = false,
  });

  @override
  State<CommonTextFormFieldClass> createState() =>
      _CommonTextFormFieldClassState();
}

class _CommonTextFormFieldClassState extends State<CommonTextFormFieldClass> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return TextFormField(
      style: TextStyle(
          fontWeight: FontWeight.w400,
          fontSize: size.width * 0.035,
          color: Colors.black),
      autovalidateMode: AutovalidateMode.onUserInteraction,
      maxLength: widget.maxLength,
      controller: widget.controller,
      obscureText: widget.obscure,
      decoration: InputDecoration(
          contentPadding: EdgeInsets.symmetric(
              horizontal: size.width * 0.05, vertical: size.width * 0.02),
          hintStyle: TextStyle(
              color: widget.hintTextColor, fontSize: size.width * 0.035),
          filled: true,
          counterText: '',
          fillColor: const Color(0xFFf8f8f8),
          prefixIcon: widget.prefixIcon,
          suffixIcon: widget.suffixIcon,
          suffix: widget.suffixWidget,
          prefixIconColor: Colors.white,
          suffixIconColor: Colors.white,
          border: widget.isEnableBorder
              ? OutlineInputBorder(
                  borderSide: const BorderSide(width: 1, color: Colors.grey),
                  borderRadius: BorderRadius.circular(size.width * 0.1),
                )
              : OutlineInputBorder(
                  borderRadius: BorderRadius.circular(7),
                  borderSide: BorderSide.none,
                ),
          enabledBorder: widget.isEnableBorder
              ? OutlineInputBorder(
                  borderSide: const BorderSide(width: 1, color: Colors.grey),
                  borderRadius: BorderRadius.circular(size.width * 0.1),
                )
              : null,
          hintText: widget.hintText),
      readOnly: widget.isRead,
      onTap: widget.onTap,
      onChanged: widget.onChange,
      maxLines: widget.maxLines,
      keyboardType: widget.keyboardType,
      inputFormatters: widget.inputFormatters,
      validator: widget.validation,
    );
  }
}

//commonText
class CommonText extends StatefulWidget {
  final String title;
  final double fontSize;
  final FontWeight fontWeight;
  final Size? size;
  final Color color;
  final bool isHashTag;
  final TextAlign? textAlign;
  final TextOverflow? overflow;
  final TextDecoration? decoration;
  final Color? decorationColor;
  final Color shadowColor;
  final double dx;
  final double dy;
  final double? letterSpacing;
  final int? maxLine;
  final double topSpacing;
  final double bottomSpacing;
  final double leftSpacing;
  final double rightSpacing;

  const CommonText({
    super.key,
    required this.title,
    this.isHashTag = false,
    required this.fontSize,
    this.fontWeight = FontWeight.w400,
    this.color = CupertinoColors.white,
    this.textAlign,
    this.overflow,
    this.size,
    this.letterSpacing,
    this.decoration = TextDecoration.none,
    this.decorationColor,
    this.shadowColor = Colors.transparent,
    this.dx = 0,
    this.dy = 0,
    this.maxLine,
    this.topSpacing = 0,
    this.bottomSpacing = 0,
    this.leftSpacing = 0,
    this.rightSpacing = 0,
  });

  @override
  State<CommonText> createState() => CommonTextState();
}

class CommonTextState extends State<CommonText> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.sizeOf(context);
    return Padding(
        padding: EdgeInsets.only(
          top: size.width * widget.topSpacing,
          bottom: size.width * widget.bottomSpacing,
          left: size.width * widget.leftSpacing,
          right: size.width * widget.rightSpacing,
        ),
        child: Text(
          widget.title,
          textAlign: widget.textAlign,
          overflow: widget.overflow,
          maxLines: widget.maxLine,
          style: commonTextStyle(),
        ));
  }

  TextStyle commonTextStyle({Color? color}) {
    var size = MediaQuery.sizeOf(context);
    return TextStyle(
        decorationColor: widget.decorationColor,
        shadows: [
          Shadow(
              offset: Offset(widget.dx, widget.dy), color: widget.shadowColor)
        ],
        decoration: widget.decoration,
        letterSpacing: widget.letterSpacing,
        fontStyle: FontStyle.normal,
        fontSize: (widget.size?.width ?? size.width) * widget.fontSize,
        fontWeight: widget.fontWeight,
        color: widget.color);
  }
}

//common button
commonButton({
  required Function func,
  required String buttonName,
  required Size size,
  double? buttonSize = 0.13,
  bool? isWidth = false,
}) {
  return SizedBox(
    height: size.width * buttonSize!,
    width: isWidth! ? double.infinity : null,
    child: DecoratedBox(
      decoration: BoxDecoration(
        gradient: linearGrad,
        borderRadius: BorderRadius.circular(size.width * 0.01),
      ),
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.transparent,
          shadowColor: Colors.transparent,
          splashFactory: NoSplash.splashFactory,
          elevation: 0,
        ),
        onPressed: () {
          func();
        },
        child: Text(
          buttonName,
          style: TextStyle(
              color: Colors.white,
              fontSize: size.width * 0.035,
              fontWeight: FontWeight.w400),
        ),
      ),
    ),
  );
}
