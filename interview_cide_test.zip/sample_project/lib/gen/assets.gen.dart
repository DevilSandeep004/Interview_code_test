/// GENERATED CODE - DO NOT MODIFY BY HAND
/// *****************************************************
///  FlutterGen
/// *****************************************************

// coverage:ignore-file
// ignore_for_file: type=lint
// ignore_for_file: directives_ordering,unnecessary_import,implicit_dynamic_list_literal,deprecated_member_use

import 'package:flutter/widgets.dart';

class $AssetsImagesGen {
  const $AssetsImagesGen();

  /// File path: assets/images/avatar 1.png
  AssetGenImage get avatar1 =>
      const AssetGenImage('assets/images/avatar 1.png');

  /// File path: assets/images/avatar 2.png
  AssetGenImage get avatar2 =>
      const AssetGenImage('assets/images/avatar 2.png');

  /// File path: assets/images/avatar 3.png
  AssetGenImage get avatar3 =>
      const AssetGenImage('assets/images/avatar 3.png');

  /// File path: assets/images/banner 1.png
  AssetGenImage get banner1 =>
      const AssetGenImage('assets/images/banner 1.png');

  /// File path: assets/images/banner 2.png
  AssetGenImage get banner2 =>
      const AssetGenImage('assets/images/banner 2.png');

  /// File path: assets/images/banner 3.png
  AssetGenImage get banner3 =>
      const AssetGenImage('assets/images/banner 3.png');

  /// File path: assets/images/bg.png
  AssetGenImage get bg => const AssetGenImage('assets/images/bg.png');

  /// File path: assets/images/home_top_bg.png
  AssetGenImage get homeTopBg =>
      const AssetGenImage('assets/images/home_top_bg.png');

  /// File path: assets/images/ic_back.png
  AssetGenImage get icBack => const AssetGenImage('assets/images/ic_back.png');

  /// File path: assets/images/ic_calendar.png
  AssetGenImage get icCalendar =>
      const AssetGenImage('assets/images/ic_calendar.png');

  /// File path: assets/images/ic_comment.png
  AssetGenImage get icComment =>
      const AssetGenImage('assets/images/ic_comment.png');

  /// File path: assets/images/ic_create.png
  AssetGenImage get icCreate =>
      const AssetGenImage('assets/images/ic_create.png');

  /// File path: assets/images/ic_cross.png
  AssetGenImage get icCross =>
      const AssetGenImage('assets/images/ic_cross.png');

  /// File path: assets/images/ic_cross_red.png
  AssetGenImage get icCrossRed =>
      const AssetGenImage('assets/images/ic_cross_red.png');

  /// File path: assets/images/ic_hamburger.png
  AssetGenImage get icHamburger =>
      const AssetGenImage('assets/images/ic_hamburger.png');

  /// File path: assets/images/ic_like_selected.png
  AssetGenImage get icLikeSelected =>
      const AssetGenImage('assets/images/ic_like_selected.png');

  /// File path: assets/images/ic_like_unselected.png
  AssetGenImage get icLikeUnselected =>
      const AssetGenImage('assets/images/ic_like_unselected.png');

  /// File path: assets/images/ic_notification.png
  AssetGenImage get icNotification =>
      const AssetGenImage('assets/images/ic_notification.png');

  /// File path: assets/images/ic_post.png
  AssetGenImage get icPost => const AssetGenImage('assets/images/ic_post.png');

  /// File path: assets/images/ic_tick.png
  AssetGenImage get icTick => const AssetGenImage('assets/images/ic_tick.png');

  /// File path: assets/images/login_bottom bg.png
  AssetGenImage get loginBottomBg =>
      const AssetGenImage('assets/images/login_bottom bg.png');

  /// File path: assets/images/login_logo.png
  AssetGenImage get loginLogo =>
      const AssetGenImage('assets/images/login_logo.png');

  /// File path: assets/images/posted image 1.png
  AssetGenImage get postedImage1 =>
      const AssetGenImage('assets/images/posted image 1.png');

  /// File path: assets/images/posted image 2.png
  AssetGenImage get postedImage2 =>
      const AssetGenImage('assets/images/posted image 2.png');

  /// File path: assets/images/speaker avatar.png
  AssetGenImage get speakerAvatar =>
      const AssetGenImage('assets/images/speaker avatar.png');

  /// File path: assets/images/splash logo grp.png
  AssetGenImage get splashLogoGrp =>
      const AssetGenImage('assets/images/splash logo grp.png');

  /// File path: assets/images/top bg.png
  AssetGenImage get topBg => const AssetGenImage('assets/images/top bg.png');

  /// List of all assets
  List<AssetGenImage> get values => [
        avatar1,
        avatar2,
        avatar3,
        banner1,
        banner2,
        banner3,
        bg,
        homeTopBg,
        icBack,
        icCalendar,
        icComment,
        icCreate,
        icCross,
        icCrossRed,
        icHamburger,
        icLikeSelected,
        icLikeUnselected,
        icNotification,
        icPost,
        icTick,
        loginBottomBg,
        loginLogo,
        postedImage1,
        postedImage2,
        speakerAvatar,
        splashLogoGrp,
        topBg
      ];
}

class Assets {
  Assets._();

  static const $AssetsImagesGen images = $AssetsImagesGen();
}

class AssetGenImage {
  const AssetGenImage(this._assetName);

  final String _assetName;

  Image image({
    Key? key,
    AssetBundle? bundle,
    ImageFrameBuilder? frameBuilder,
    ImageErrorWidgetBuilder? errorBuilder,
    String? semanticLabel,
    bool excludeFromSemantics = false,
    double? scale,
    double? width,
    double? height,
    Color? color,
    Animation<double>? opacity,
    BlendMode? colorBlendMode,
    BoxFit? fit,
    AlignmentGeometry alignment = Alignment.center,
    ImageRepeat repeat = ImageRepeat.noRepeat,
    Rect? centerSlice,
    bool matchTextDirection = false,
    bool gaplessPlayback = false,
    bool isAntiAlias = false,
    String? package = 'sample_project',
    FilterQuality filterQuality = FilterQuality.low,
    int? cacheWidth,
    int? cacheHeight,
  }) {
    return Image.asset(
      _assetName,
      key: key,
      bundle: bundle,
      frameBuilder: frameBuilder,
      errorBuilder: errorBuilder,
      semanticLabel: semanticLabel,
      excludeFromSemantics: excludeFromSemantics,
      scale: scale,
      width: width,
      height: height,
      color: color,
      opacity: opacity,
      colorBlendMode: colorBlendMode,
      fit: fit,
      alignment: alignment,
      repeat: repeat,
      centerSlice: centerSlice,
      matchTextDirection: matchTextDirection,
      gaplessPlayback: gaplessPlayback,
      isAntiAlias: isAntiAlias,
      package: package,
      filterQuality: filterQuality,
      cacheWidth: cacheWidth,
      cacheHeight: cacheHeight,
    );
  }

  ImageProvider provider({
    AssetBundle? bundle,
    String? package = 'sample_project',
  }) {
    return AssetImage(
      _assetName,
      bundle: bundle,
      package: package,
    );
  }

  String get path => _assetName;

  String get keyName => 'packages/sample_project/$_assetName';
}
