import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sample_project/controller/homeController.dart';
import 'package:sample_project/gen/assets.gen.dart';
import 'package:sample_project/utils/commonUtils.dart';
import 'package:sample_project/views/commentScreen/commentScreen.dart';
import '../../main.dart';

class FeedView extends StatefulWidget {
  const FeedView({super.key});

  @override
  State<FeedView> createState() => _FeedViewState();
}

class _FeedViewState extends State<FeedView> {

  final _homeController = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
              actions: [
                IconButton(
                    onPressed: () {
                      filterBottomSheet();
                    },
                    icon: Image.asset(
                      Assets.images.icCreate.path,
                      height: Get.width * 0.05,
                    ))
              ],
              title: const CommonText(
                  title: "Logo",
                  fontSize: 0.05,
                  fontWeight: FontWeight.w700),
              centerTitle: true,
              leading: IconButton(
                  onPressed: () {
                    Get.back();
                  },
                  icon: Image.asset('${imagePath}ic_back.png',
                      height: Get.width * 0.05)),
              backgroundColor: Colors.transparent,
              flexibleSpace: FlexibleSpaceBar(
                background:
                Image.asset("${imagePath}top bg.png", fit: BoxFit.fill),
              ),
              expandedHeight: Get.width * 0.05,
              floating: true,
              pinned: true),
          //What happen
          Obx(
            () {
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  childCount: _homeController.feedList.length,
                      (BuildContext context, int index) {
                    return Obx(
                       () {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(
                                  horizontal: Get.width * 0.04),
                              width: double.infinity,
                              padding: EdgeInsets.all(Get.width * 0.02),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Image.asset(
                                          _homeController.feedList[index].image!,
                                          height: Get.width * 0.1),
                                      SizedBox(width: Get.width * 0.02),
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          CommonText(
                                              title: _homeController.feedList[index].name!,
                                              fontSize: 0.03,
                                              color: Colors.black,
                                              fontWeight: FontWeight.w700),
                                          CommonText(
                                              title:
                                              "Posted ${_homeController.feedList[index].postTime!} minutes ago",
                                              fontSize: 0.025,
                                              color: Colors.orange,
                                              fontWeight: FontWeight.w500),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: Get.width * 0.02),
                                  _homeController.feedList[index].newPost != null
                                      ? Image.file(
                                      _homeController.feedList[index].newPost!)
                                      : Image.asset(_homeController.feedList[index].postImage!),
                                  SizedBox(height: Get.width * 0.02),
                                  Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            InkWell(
                                              onTap: () {
                                                _homeController.clickLike(index);
                                              },
                                              child: Image.asset(
                                                  _homeController.feedList[index]
                                                      .isLike!
                                                      ? "${imagePath}ic_like_selected.png"
                                                      : "${imagePath}ic_like_unselected.png",
                                                  height: Get.width * 0.05),
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            CommonText(
                                              title: _homeController.feedList[index].noOfLike!,
                                              fontSize: 0.03,
                                              fontWeight: FontWeight.w400,
                                              color: const Color(0xFF0f0f0f),
                                            )
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            CommonText(
                                              title: _homeController.feedList[index]
                                                  .noOfComments!,
                                              fontSize: 0.03,
                                              fontWeight: FontWeight.w400,
                                              color: const Color(0xFF0f0f0f),
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            InkWell(
                                              onTap: () {
                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            CommentSectionScreen(
                                                              name: _homeController.feedList[index]
                                                                  .name!,
                                                              comment: _homeController.feedList[index]
                                                                  .comment!,
                                                              noLike: _homeController.feedList[index]
                                                                  .noOfLike!,
                                                              noComments: _homeController.feedList[index]
                                                                  .noOfComments!,
                                                              image: _homeController.feedList[index]
                                                                  .image!,
                                                            )));
                                              },
                                              child: Image.asset(
                                                  "${imagePath}ic_comment.png",
                                                  height: Get.width * 0.05),
                                            ),
                                          ],
                                        ),
                                      ]),
                                  SizedBox(height: Get.width * 0.02),
                                  _homeController.feedList[index].comment!.isNotEmpty
                                      ? CommonText(
                                    title: _homeController.feedList[index].comment!,
                                    fontSize: 0.035,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  )
                                      : Container()
                                ],
                              ),
                            ),
                            Divider(
                              height: Get.width * 0.05,
                              thickness: 0,
                            ),
                          ],
                        );
                      }
                    );
                  },
                  // 40 list items

                ),
              );
            }
          ),
        ],
      ),
    );
  }


void filterBottomSheet() {
  Get.bottomSheet(Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Padding(
        padding: EdgeInsets.all(Get.width * 0.02),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: Image.asset("${imagePath}ic_cross_red.png",
                    height: Get.width * 0.05)),
            IconButton(
                onPressed: () {
                  _homeController.addToFeedList();
                  Get.back();
                },
                icon: Image.asset("${imagePath}ic_tick.png",
                    height: Get.width * 0.05))
          ],
        ),
      ),
      Container(
        margin: EdgeInsets.symmetric(horizontal: Get.width * 0.05),
        padding: EdgeInsets.symmetric(vertical: Get.width * 0.05),
        width: double.infinity,
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(
                Radius.circular(Get.width * 0.03)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.1),
                offset: const Offset(
                  1.0,
                  1.0,
                ),
                blurRadius: 4.0,
                spreadRadius: 1.0,
              ),
            ]),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Obx(
                    () {
                return _homeController.imageFile.isNotEmpty
                    ? ClipRRect(
                  borderRadius: BorderRadius.all(
                      Radius.circular(Get.width * 0.02)),
                  child: SizedBox(
                    height: Get.width * 0.8,
                    width: Get.width * 0.5,
                    child: Column(
                      children: [
                        Container(
                            alignment: Alignment.bottomRight,
                            width: double.infinity,
                            height: Get.width * 0.08,
                            decoration: const BoxDecoration(
                                color: Color(0xFF7b05c3)),
                            child: IconButton(
                                onPressed: () {
                                  _homeController.imageFile.value = "";
                                },
                                icon: Image.asset(
                                  "${imagePath}ic_cross.png",
                                ))),
                        Image.file(File(_homeController.imageFile.value)),
                      ],
                    ),
                  ),
                )
                    : Container();
              }
            ),
            SizedBox(height: Get.width * 0.02),
            CommonTextFormFieldClass(
                controller: _homeController.feedController,
                hintTextColor: Colors.grey,
                hintText: "Write Something..."),
          ],
        ),
      ),
      SizedBox(height: Get.width * 0.05),
      Padding(
        padding:
        EdgeInsets.symmetric(horizontal: Get.width * 0.04),
        child: commonButton(
            func: () {
              showImagePickerOptions();
            },
            buttonName: "Add Image",
            size: Get.size,
            buttonSize: 0.08),
      )
    ],
  ));

}

// image picker
Future showImagePickerOptions() async {
  showCupertinoModalPopup(
    context: navigatorKey.currentContext!,
    builder: (context) => CupertinoActionSheet(
      actions: [
        CupertinoActionSheetAction(
          child: const Text('Gallery'),
          onPressed: () {
            Navigator.of(context).pop();
            _homeController.pickImageFromSource(source: ImageSource.gallery);
          },
        ),
        CupertinoActionSheetAction(
          child: const Text('Camera'),
          onPressed: () {
            Navigator.of(context).pop();
            _homeController.pickImageFromSource(source: ImageSource.camera);
          },
        ),
      ],
    ),
  );
}
}