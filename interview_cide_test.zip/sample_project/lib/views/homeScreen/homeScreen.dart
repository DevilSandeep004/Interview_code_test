import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_project/controller/homeController.dart';
import 'package:sample_project/gen/assets.gen.dart';
import 'package:sample_project/routes/routes.dart';
import 'package:sample_project/utils/commonUtils.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  
  final _homeController = Get.put(HomeController());
  
  
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
              actions: [
                IconButton(
                    onPressed: () {},
                    icon: Image.asset(
                      Assets.images.icNotification.path,
                      height: Get.width * 0.05,
                    ))
              ],
              title: const CommonText(
                  title: "Logo",
                  fontSize: 0.05,
                  fontWeight: FontWeight.w700),
              centerTitle: true,
              leading: IconButton(
                  onPressed: () {
                    filterBottomSheet();
                  },
                  icon: Image.asset('${imagePath}ic_hamburger.png',
                      height: Get.width * 0.05)),
              backgroundColor: Colors.transparent,
              flexibleSpace: FlexibleSpaceBar(
                titlePadding: EdgeInsets.symmetric(
                    horizontal: Get.width * 0.04, vertical: Get.width * 0.04),
                expandedTitleScale: 1.0,
                title: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    const CommonText(
                        title: 'Upcoming Events',
                        fontSize: 0.035,
                        fontWeight: FontWeight.w700),
                    SizedBox(height: Get.width * 0.02),
                    Container(
                      width: double.infinity,
                      padding: EdgeInsets.all(Get.width * 0.02),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(
                              Radius.circular(Get.width * 0.03)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(.1),
                              offset: const Offset(
                                1.0,
                                1.0,
                              ),
                              blurRadius: 4.0,
                              spreadRadius: 1.0,
                            ),
                          ]),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const CommonText(
                              title: 'Session: Ice Breaker Games Activity',
                              fontSize: 0.03,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                            SizedBox(height: Get.width * 0.02),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Image.asset("${imagePath}ic_calendar.png",
                                    height: Get.width * 0.04),
                                SizedBox(width: Get.width * 0.02),
                                const CommonText(
                                  title: '5 Jan | 1:00 PM - 1:30 PM',
                                  fontSize: 0.025,
                                  color: Color(0xFF7b05c3),
                                  fontWeight: FontWeight.w400,
                                ),
                              ],
                            ),
                          ]),
                    )
                  ],
                ),
                background:
                Image.asset("${imagePath}top bg.png", fit: BoxFit.fill),
              ),
              expandedHeight: Get.width * 0.4,
              floating: true,
              collapsedHeight: Get.width * 0.4,
              pinned: true),
          SliverList(
            delegate: SliverChildBuilderDelegate(
                  (BuildContext context, int index) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CarouselSlider.builder(
                      itemCount: _homeController.carouselList.length,
                      itemBuilder: (BuildContext context, int itemIndex,
                          int pageViewIndex) =>
                          Image.asset(_homeController.carouselList[index]),
                      options: CarouselOptions(
                        height: 180.0,
                        enlargeCenterPage: true,
                        autoPlay: true,
                        aspectRatio: 16 / 9,
                        autoPlayCurve: Curves.fastOutSlowIn,
                        enableInfiniteScroll: true,
                        autoPlayAnimationDuration:
                        const Duration(milliseconds: 800),
                        viewportFraction: 0.8,
                      ),
                    ),

                    //Featured speakers
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: Get.width * 0.04, vertical: Get.width * 0.04),
                      child: const CommonText(
                          title: 'Featured Speakers',
                          fontSize: 0.035,
                          fontWeight: FontWeight.w700,
                          color: Colors.black),
                    ),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: Get.width * 0.04),
                      width: double.infinity,
                      padding: EdgeInsets.all(Get.width * 0.02),
                      decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.all(
                              Radius.circular(Get.width * 0.03)),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(.1),
                              offset: const Offset(
                                1.0,
                                1.0,
                              ),
                              blurRadius: 4.0,
                              spreadRadius: 1.0,
                            ),
                          ]),
                      child: Row(
                        children: [
                          Column(
                            children: [
                              Image.asset("${imagePath}speaker avatar.png",
                                  height: Get.width * 0.1),
                              const CommonText(
                                  title: "Alisha Shikhar",
                                  fontSize: 0.03,
                                  color: Colors.black,
                                  fontWeight: FontWeight.w700),
                              SizedBox(height: Get.width * 0.01),
                              const CommonText(
                                  title: "Yoga Expert",
                                  fontSize: 0.03,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.grey),
                            ],
                          ),
                          SizedBox(width: Get.width * 0.02),
                          Container(
                            width: Get.width * 0.001,
                            height: Get.width * 0.2,
                            color: Colors.grey,
                          ),
                          SizedBox(width: Get.width * 0.02),
                          Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment:
                              MainAxisAlignment.spaceBetween,
                              children: [
                                const CommonText(
                                  title: 'Session: way to a Calm Mind',
                                  fontSize: 0.03,
                                  color: Colors.black,
                                  fontWeight: FontWeight.bold,
                                ),
                                SizedBox(height: Get.width * 0.02),
                                Row(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                        "${imagePath}ic_calendar.png",
                                        height: Get.width * 0.04),
                                    SizedBox(width: Get.width * 0.02),
                                    const CommonText(
                                      title: '5 Jan | 1:00 PM - 1:30 PM',
                                      fontSize: 0.025,
                                      color: Color(0xFF7b05c3),
                                      fontWeight: FontWeight.w400,
                                    ),
                                  ],
                                ),
                              ]),
                        ],
                      ),
                    ),

                    //Featured speakers
                    Padding(
                      padding: EdgeInsets.symmetric(
                          horizontal: Get.width * 0.04, vertical: Get.width * 0.04),
                      child: const CommonText(
                          title: 'What\'s Happening Around you!',
                          fontSize: 0.035,
                          fontWeight: FontWeight.w700,
                          color: Colors.black),
                    ),
                  ],
                );
              },
              // 40 list items
              childCount: 1,
            ),
          ),

          //What happen
          Obx(
            () {
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  childCount: _homeController.feedList.length,
                      (BuildContext context, int index) {
                    return Obx(
                      () {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.symmetric(horizontal: Get.width * 0.04),
                              width: double.infinity,
                              padding: EdgeInsets.all(Get.width * 0.02),

                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Image.asset("${imagePath}speaker avatar.png",
                                          height: Get.width * 0.1),
                                      SizedBox(width: Get.width * 0.02),
                                      Column(
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          CommonText(
                                              title: _homeController.feedList[index].name!,
                                              fontSize: 0.03,
                                              color: Colors.black,
                                              fontWeight: FontWeight.w700),
                                          CommonText(
                                              title:
                                              "Posted ${_homeController.feedList[index].postTime!} minutes ago",
                                              fontSize: 0.025,
                                              color: Colors.orange,
                                              fontWeight: FontWeight.w500),
                                        ],
                                      ),
                                    ],
                                  ),
                                  SizedBox(height: Get.width * 0.02),
                                  Image.asset(
                                      _homeController.feedList[index].postImage!),
                                  SizedBox(height: Get.width * 0.02),
                                  Row(
                                      mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            InkWell(
                                              onTap: () {
                                                _homeController.clickLike(index);
                                              },
                                              child: Image.asset(
                                                  _homeController.feedList[index]
                                                      .isLike!
                                                      ? "${imagePath}ic_like_selected.png"
                                                      : "${imagePath}ic_like_unselected.png",
                                                  height: Get.width * 0.05),
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            CommonText(
                                              title: _homeController.feedList[index].noOfLike!,
                                              fontSize: 0.03,
                                              fontWeight: FontWeight.w400,
                                              color: const Color(0xFF0f0f0f),
                                            )
                                          ],
                                        ),
                                        Row(
                                          children: [
                                            CommonText(
                                              title: _homeController.feedList[index]
                                                  .noOfComments!,
                                              fontSize: 0.03,
                                              fontWeight: FontWeight.w400,
                                              color: const Color(0xFF0f0f0f),
                                            ),
                                            SizedBox(width: Get.width * 0.02),
                                            Image.asset(
                                                "${imagePath}ic_comment.png",
                                                height: Get.width * 0.05),
                                          ],
                                        ),
                                      ]),
                                  SizedBox(height: Get.width * 0.02),
                                  _homeController.feedList[index].comment!.isNotEmpty
                                      ? CommonText(
                                    title: _homeController.feedList[index].comment!,
                                    fontSize: 0.035,
                                    color: Colors.grey,
                                    fontWeight: FontWeight.w500,
                                  )
                                      : Container()
                                ],
                              ),
                            ),
                            Divider(
                              height: Get.width * 0.05,
                              thickness: 0,
                            ),
                          ],
                        );
                      }
                    );
                  },
                  // 40 list items

                ),
              );
            }
          ),
        ],
      ),
    );
  }
}

void filterBottomSheet() {
  Get.bottomSheet(Container(
    padding: EdgeInsets.symmetric(vertical: Get.width * 0.05),
    width: double.infinity,
    decoration: const BoxDecoration(color: Color(0xFF7006cb)),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Row(
          children: [
            const Spacer(),
            SizedBox(width: Get.width * 0.1),
            const CommonText(
                title: "Logo",
                fontSize: 0.05,
                fontWeight: FontWeight.w700),
            const Spacer(),
            IconButton(
                onPressed: () {
                  Get.back();
                },
                icon: Image.asset("${imagePath}ic_cross.png",
                    height: Get.width * 0.05))
          ],
        ),
        SizedBox(height: Get.width * 0.05),
        InkWell(
            onTap: () {
              Get.back();
            },
            child:
            const CommonText(title: "Home", fontSize: 0.035)),
        SizedBox(height: Get.width * 0.02),
        InkWell(
            onTap: () async{
              await Get.toNamed(Routes.FEED_VIEW_ROUTE);
              Get.back();
            },
            child:
            const CommonText(title: "Feed", fontSize: 0.035)),
        const Spacer(),
        const Divider()
      ],
    ),
  ));

}
