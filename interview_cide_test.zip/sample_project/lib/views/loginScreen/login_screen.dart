import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_project/controller/loginController.dart';
import 'package:sample_project/gen/assets.gen.dart';
import 'package:sample_project/utils/commonUtils.dart';




class LoginView extends StatefulWidget {
  const LoginView({super.key});

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> {
  final _loginController = Get.put<LoginController>(LoginController());

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.sizeOf(context);
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: loginWidget(size),
    );
  }

  Widget loginWidget(Size size) {
    return Form(
      key: _loginController.formKey,
      child: Column(children: [
        Container(
            margin: EdgeInsets.symmetric(
                horizontal: size.width * 0.08, vertical: size.width * 0.1),
            padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius:
                BorderRadius.all(Radius.circular(size.width * 0.03)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.1),
                    offset: const Offset(
                      1.0,
                      1.0,
                    ),
                    blurRadius: 4.0,
                    spreadRadius: 1.0,
                  ),
                ]),
            child: Column(children: [
              Image.asset(
                Assets.images.splashLogoGrp.path,
                fit: BoxFit.fill,
                height: size.width * 0.4,
              ),
              SizedBox(height: size.width * 0.02),
              CommonTextFormFieldClass(
                  controller: _loginController.mobileController,
                  keyboardType: TextInputType.number,
                  validation: (value) {
                    return commonFormValidation(
                        value: value, type: ValidationEnum.mobile);
                  },
                  hintTextColor: const Color(0xFF616161),
                  hintText: "Mobile Number"),
              SizedBox(height: size.width * 0.02),
              CommonTextFormFieldClass(
                  controller: _loginController.passController,
                  validation: (value) {
                    return commonFormValidation(
                        value: value, type: ValidationEnum.password);
                  },
                  hintTextColor: const Color(0xFF616161),
                  hintText: "Password"),
              SizedBox(height: size.width * 0.05),
              commonButton(
                isWidth: true,
                func: _loginController.clickLoginButton,
                buttonName: "Login",
                size: size,
              ),
              SizedBox(height: size.width * 0.05),
            ])),
        const CommonText(
          title: "GOA",
          fontSize: 0.05,
          color: Color(0xFF7b05c3),
          fontWeight: FontWeight.w700,
        ),
        const CommonText(
          title: "5 Jan - 8 Jan",
          fontSize: 0.035,
          color: Color(0xFF7b05c3),
          fontWeight: FontWeight.w400,
        ),
        SizedBox(height: size.width * 0.02),
        Expanded(
          child: Image.asset(
            "${imagePath}login_bottom bg.png",
            height: size.width * 0.5,
            width: double.infinity,
            fit: BoxFit.fill,
          ),
        ),
      ]),
    );
  }
}
