import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_project/gen/assets.gen.dart';
import 'package:sample_project/routes/routes.dart';


class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> {

  @override
  void initState() {
    Future.delayed(Duration(seconds: 5),()=> Get.offAllNamed(Routes.LOGIN_VIEW_ROUTE));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Colors.black,
      body: SizedBox(
          height: size.height,
          width: size.width,
          child: Stack(
            alignment: Alignment.center,
            children: [
              Image.asset(
                Assets.images.bg.path,
                fit: BoxFit.fill,
                width: double.infinity,
              ),
              Image.asset(
                Assets.images.splashLogoGrp.path,
                fit: BoxFit.fill,
                height: size.width * 0.4,
              ),
            ],
          )),
    );
  }
}
