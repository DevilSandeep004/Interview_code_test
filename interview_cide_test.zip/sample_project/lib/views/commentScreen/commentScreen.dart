import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../utils/commonUtils.dart';

class CommentSectionScreen extends StatelessWidget {
  final String name;
  final String image;
  final String comment;
  final String noLike;
  final String noComments;

  const CommentSectionScreen(
      {super.key,
      required this.name,
      required this.comment,
      required this.noLike,
      required this.noComments,
      required this.image});

  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.sizeOf(context);
    return Scaffold(
      bottomNavigationBar: Container(
        padding: EdgeInsets.all(size.width * 0.02),
        decoration: BoxDecoration(
            border: Border.all(
          color: Colors.grey.withOpacity(0.2),
        )),
        child: CommonTextFormFieldClass(
          isEnableBorder: true,
          hintText: 'Write a comment...',
          hintTextColor: Colors.grey,
          suffixIcon: Padding(
            padding: EdgeInsets.all(size.width * 0.02),
            child: Image.asset(
              "${imagePath}ic_post.png",
              height: size.width * 0.05,
              width: size.width * 0.05,
            ),
          ),
        ),
      ),
      appBar: AppBar(
        backgroundColor: const Color(0xFF7b05c3),
        actions: [
          IconButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              icon: Image.asset("${imagePath}ic_cross.png",
                  height: size.width * 0.05))
        ],
        leading: Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.02),
          child: Image.asset(image,
              height: size.width * 0.05, width: size.width * 0.05),
        ),
        titleSpacing: 0,
        title: CommonText(
            title: name.toUpperCase(),
            fontSize: 0.04,
            fontWeight: FontWeight.w500),
      ),
      body: Column(
        children: [
          commentWidget(size),
          listOfCommentsWidget(size),
        ],
      ),
    );
  }

  Widget commentWidget(Size size) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset("${imagePath}posted image 1.png"),
        SizedBox(height: size.width * 0.02),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
          child:
              Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Row(
              children: [
                InkWell(
                  onTap: () {},
                  child: Image.asset("${imagePath}ic_like_selected.png",
                      height: size.width * 0.05),
                ),
                SizedBox(width: size.width * 0.02),
                CommonText(
                  title: noLike,
                  fontSize: 0.03,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF0f0f0f),
                )
              ],
            ),
            Row(
              children: [
                CommonText(
                  title: noComments,
                  fontSize: 0.03,
                  fontWeight: FontWeight.w400,
                  color: const Color(0xFF0f0f0f),
                ),
                SizedBox(width: size.width * 0.02),
                Image.asset("${imagePath}ic_comment.png",
                    height: size.width * 0.05),
              ],
            ),
          ]),
        ),
        SizedBox(height: size.width * 0.02),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: size.width * 0.04),
          child: CommonText(
            title: comment,
            fontSize: 0.035,
            color: Colors.grey,
            fontWeight: FontWeight.w500,
          ),
        ),
        SizedBox(height: size.width * 0.02),
        const Divider(height: 0),
      ],
    );
  }

  Widget listOfCommentsWidget(Size size) {
    return Expanded(
      child: ListView.separated(
        padding: EdgeInsets.symmetric(
            vertical: size.width * 0.04, horizontal: size.width * 0.04),
        shrinkWrap: true,
        itemCount: 10,
        itemBuilder: (context, index) {
          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Image.asset(
                "${imagePath}speaker avatar.png",
                height: size.width * 0.1,
              ),
              SizedBox(width: size.width * 0.04),
              Expanded(
                child: Container(
                  padding: EdgeInsets.all(size.width * 0.02),
                  width: size.width * 0.8,
                  decoration: BoxDecoration(
                    color: const Color(0xFFf1e2fd).withOpacity(0.2),
                    borderRadius:
                        BorderRadius.all(Radius.circular(size.width * 0.02)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const CommonText(
                          title: 'KALPANA',
                          fontSize: 0.035,
                          color: Colors.black,
                          fontWeight: FontWeight.w700),
                      SizedBox(height: size.width * .01),
                      const CommonText(
                          title:
                              'This was the best activity for me. Enjoyed a lot with you guys.asdasdas',
                          fontSize: 0.03,
                          color: Colors.grey,
                          fontWeight: FontWeight.w400)
                    ],
                  ),
                ),
              )
            ],
          );
        },
        separatorBuilder: (BuildContext context, int index) {
          return SizedBox(
            height: size.width * 0.02,
          );
        },
      ),
    );
  }
}
