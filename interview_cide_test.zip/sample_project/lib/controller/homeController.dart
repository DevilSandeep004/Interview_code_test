import 'dart:ffi';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:sample_project/gen/assets.gen.dart';
import 'package:sample_project/utils/commonModal.dart';

class HomeController extends GetxController {
  TextEditingController feedController = TextEditingController();
  RxList<FeedModal> feedList = <FeedModal>[].obs;
  List<String> carouselList = [];
  RxString imageFile = "".obs;

  @override
  void onInit() {
    loadData();
    super.onInit();
  }

  void loadData(){
    feedList.add(
      FeedModal("Ankit Rastogi",
          Assets.images.avatar1.path,
          null,
          false,
          '10',
          '12',
          Assets.images.postedImage1.path,
          '14',
          'Plantation Activity made fun!',
          null)
    );

    feedList.add(FeedModal(
        "Kalpana Rastogi",
        Assets.images.avatar1.path,
        null,
        false,
        '10',
        '12',
        Assets.images.postedImage1.path,
        '14',
        'Fitness check, which team will win?',
        null));

    feedList.add(FeedModal(
        "Ankit Rastogi",
        Assets.images.avatar1.path,
        null,
        false,
        '10',
        '12',
        Assets.images.postedImage1.path,
        '14',
        '',
        null));

    carouselList.addAll(
      [
        Assets.images.banner1.path,
        Assets.images.banner2.path,
        Assets.images.banner3.path,
      ]
    );

  }

  clickLike(int index) {
    feedList[index].isLike = !(feedList[index].isLike ?? false);
    feedList.refresh();
  }

  ///ImagePicker
  Future<void> pickImageFromSource({required ImageSource source}) async {
    try {
      final pickedFile = await ImagePicker().pickImage(
        source: source,
      );
      imageFile.value = pickedFile?.path ?? "";
      debugPrint('PickedFile:- ${imageFile.value}');
    } catch (error) {
      debugPrint('Error picking image: ${error.toString()}');
    }
  }

  void addToFeedList() {
    feedList.add(FeedModal('Dummy', Assets.images.avatar1.path, null,
        false, '0', '0', 'null', '0', feedController.text, File(imageFile.value)));
    feedController.clear();
  }


}


