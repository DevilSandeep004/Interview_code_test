import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:sample_project/routes/routes.dart';

class LoginController extends GetxController {

  final formKey = GlobalKey<FormState>();

  TextEditingController mobileController = TextEditingController();
  TextEditingController passController = TextEditingController();

 void clickLoginButton() {
    /*if (formKey.currentState!.validate()) {

      debugPrint("All valid");
    } else {
      debugPrint("Not valid");
    }*/
   Get.offAllNamed(Routes.HOME_VIEW_ROUTE);
  }


}
