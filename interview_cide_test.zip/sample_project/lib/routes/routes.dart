import 'package:get/get.dart';
import 'package:sample_project/views/feedScreen/feedView.dart';
import 'package:sample_project/views/homeScreen/homeScreen.dart';
import 'package:sample_project/views/loginScreen/login_screen.dart';
import 'package:sample_project/views/splash/splash.dart';

class Routes {
  //  * Variables * //
  static const String INITIAL_ROUTE = '/';
  static const String LOGIN_VIEW_ROUTE = '/login-screen-view-route';
  static const String HOME_VIEW_ROUTE = '/home-screen-view-route';
  static const String FEED_VIEW_ROUTE = '/feed-screen-view-route';
  /*static const String REGISTER_VIEW_ROUTE = '/register-screen-view-route';
  static const String OTP_VIEW_ROUTE = '/otp-screen-view-route';
  static const String ORDER_BOOK_VIEW_ROUTE = '/order_book-view-route';
  static const String FORGOT_VIEW_ROUTE = '/forgot-screen-view-route';
  static const String RESET_VIEW_ROUTE = '/reset-screen-view-route';
  static const String HOME_VIEW_ROUTE = '/home-screen-view-route';
  static const String ADD_ADDRESS_VIEW_ROUTE = '/add-address-view-route';
  static const String PROFILE_VIEW_ROUTE = '/profile-view-route';
  static const String EDIT_PROFILE_VIEW = '/edit-profile-view-route';
  static const String ORDER_DETAIL_VIEW_ROUTE = '/order-Detail-view-route';
  static const String DASHBOARD_VIEW_ROUTE = '/dashboard-view-route';
  static const String ADDRESS_VIEW_ROUTE = '/address-view-route';
  static const String CART_VIEW_ROUTE = '/cart-view-route';
  static const String SUPPORT_VIEW_ROUTE = '/support-view-route';
  static const String CHANGE_PASSWORD_VIEW_ROUTE =
      '/change-password-view-route';
  static const String RESTAURANT_VIEW_ROUTE = '/restaurant-view-route';
  static const String PRODUCT_DETAIL_VIEW_ROUTE = '/product-detail-view-route';
  static const String CREDIT_CARD_VIEW_ROUTE = '/credit-card-view-route';*/


  //  * Functions * //
  List<GetPage<dynamic>>? getPages() {
    return [
      GetPage(name: INITIAL_ROUTE, page: () => SplashView()),
      GetPage(name: LOGIN_VIEW_ROUTE, page: () => LoginView(),transition: Transition.rightToLeft),
      GetPage(name: HOME_VIEW_ROUTE, page: () => HomeScreen(),transition: Transition.downToUp,transitionDuration: Duration(seconds: 1)),
      GetPage(name: FEED_VIEW_ROUTE, page: () => FeedView(),transition: Transition.upToDown,transitionDuration: Duration(microseconds: 2000)),
    ];
  }
}
