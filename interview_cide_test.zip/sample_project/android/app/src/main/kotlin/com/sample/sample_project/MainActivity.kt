package com.sample.sample_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
